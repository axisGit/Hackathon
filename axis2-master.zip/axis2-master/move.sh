rm -rf ../nodeFront/app
cp -r ./app ../nodeFront
