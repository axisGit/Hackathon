# AxisHachkathon
 This Project is divided into two parts: 1. The estimation of Hurricane damage(quantified as loss) 2. The mapping of the hurricane path.
 \
Contributors: Timothy, Kevin (Mapping of data) Peng, Guanzhong(Loss estimation)
